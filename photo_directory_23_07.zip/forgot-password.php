<?php
require 'includes/conn.php';
$success = "";
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);

    $stmt = $pdo->prepare("SELECT * FROM members WHERE email = ? AND is_verified = 1 AND approved = 1");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user) {
        $token = bin2hex(random_bytes(16));
        $expires = date("Y-m-d H:i:s", strtotime("+1 hour"));

        $update = $pdo->prepare("UPDATE members SET reset_token = ?, reset_token_expires = ? WHERE id = ?");
        $update->execute([$token, $expires, $user['id']]);

        $resetLink = "http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/reset-password.php?token=$token";

        $subject = "Reset your password - St. Timothy";
        $message = "Hi {$user['first_name']},\n\nPlease click the link below to reset your password:\n$resetLink\n\nThis link is valid for 1 hour.\n\nSt. Timothy Church";
        $headers = "From: no-reply@sttimothy.ca";

        mail($email, $subject, $message, $headers);

        $success = "✅ A reset link has been sent to your email.";
    } else {
        $error = "No verified user found with this email.";
    }
}
?>

<?php include 'includes/header.php'; ?>
<div class="container py-5">
    <h2>Forgot Password</h2>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php elseif ($success): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>
    <form method="POST">
        <div class="mb-3">
            <label>Email address</label>
            <input type="email" name="email" required class="form-control">
        </div>
        <button type="submit" class="btn btn-primary">Send Reset Link</button>
        <a href="login.php" class="btn btn-link">Back to login</a>
    </form>
</div>
<?php include 'includes/footer.php'; ?>
